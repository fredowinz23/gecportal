package com.thesis.onlinecounseling.booking

import com.google.gson.annotations.SerializedName

data class AppointmentReportRequest(

    @SerializedName("appointmentId")
    var appointmentId: Int = 0,

    @SerializedName("report")
    var report: String = "",

    @SerializedName("success")
    var success: String = "",

)