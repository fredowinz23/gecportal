package com.thesis.onlinecounseling.booking

import android.app.DatePickerDialog
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.thesis.onlinecounseling.R
import com.thesis.onlinecounseling.api.ApiInterface
import com.thesis.onlinecounseling.api.RetrofitClient
import com.thesis.onlinecounseling.api.UserSession
import com.thesis.onlinecounseling.databinding.ActivityAppointmentReportBinding
import com.thesis.onlinecounseling.databinding.ActivityAppointmentReportFormBinding
import com.thesis.onlinecounseling.databinding.ActivityBookingFormBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.*

class AppointmentReportActivity : AppCompatActivity() {

    lateinit var binding: ActivityAppointmentReportBinding
    var report = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityAppointmentReportBinding.inflate(layoutInflater)
        setContentView(binding.root)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

        report = intent.extras?.getString("report", "")!!


        binding.ivBack.setOnClickListener {
            finish()
        }

        binding.tvReport.text = report

    }

}