package com.thesis.onlinecounseling.models

import com.google.gson.annotations.SerializedName

data class Appointment(
    @SerializedName("Id")
    var id: Int = 0,

    @SerializedName("createdBy")
    var createdBy: Int = 0,

    @SerializedName("studentId")
    var studentId: String = "",

    @SerializedName("appointmentDate")
    var appointmentDate: String = "",

    @SerializedName("appointmentTime")
    var appointmentTime: String = "",

    @SerializedName("appointmentType")
    var appointmentType: String = "",

    @SerializedName("dateAdded")
    var dateAdded: String = "",

    @SerializedName("status")
    var status: String = "",

    @SerializedName("purpose")
    var purpose: String = "",

    @SerializedName("zoomLink")
    var zoomLink: String = "",

    @SerializedName("report")
    var report: String = "",

)