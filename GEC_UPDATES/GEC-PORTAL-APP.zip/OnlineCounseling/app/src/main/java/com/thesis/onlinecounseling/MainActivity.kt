package com.thesis.onlinecounseling

import android.R
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.TaskStackBuilder
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.RemoteViews
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.thesis.onlinecounseling.api.UserSession
import com.thesis.onlinecounseling.auth.LoginActivity
import com.thesis.onlinecounseling.booking.*
import com.thesis.onlinecounseling.databinding.ActivityMainBinding


class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    val CHANNEL_ID = "channelID"
    val CHANNEL_NAME = "channelName"
    val NOTIF_ID = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

        binding.llMyBookings.setOnClickListener {
            startActivity(Intent(this, MyBookingActivity::class.java))
        }

        binding.llBookingStudent.setOnClickListener {
            val intent = Intent(this, BookingFormActivity::class.java)
            intent.putExtra("studentId", UserSession(this).userId)
            intent.putExtra("studentName", UserSession(this).fullName)
            startActivity(intent)
        }

        binding.llBookingTeacher.setOnClickListener {
            val intent = Intent(this, BookStudentFormActivity::class.java)
            intent.putExtra("userId", UserSession(this).userId)
            intent.putExtra("fullName", UserSession(this).fullName)
            startActivity(intent)
        }

        binding.llBookingCounselor.setOnClickListener {
            val intent = Intent(this, BookStudentFormActivity::class.java)
            intent.putExtra("userId", UserSession(this).userId)
            intent.putExtra("fullName", UserSession(this).fullName)
            startActivity(intent)
        }

        binding.llTodaysAppointment.setOnClickListener {
            startActivity(Intent(this, TodaysAppointmentActivity::class.java))
        }

        binding.tvFullName.text = UserSession(this).fullName
        binding.tvUsername.text = UserSession(this).username

        binding.llLogout.setOnClickListener {
            val userSession = UserSession(this)
            userSession.edit?.clear()
            userSession.edit?.apply()
            Log.e("Activity reached", "logout")
            Toast.makeText(
                this,
                "Logged out successfully",
                Toast.LENGTH_LONG
            ).show()
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }

        val role = UserSession(this).role
        if (role=="Teacher"){
            binding.llBookingTeacher.visibility = View.VISIBLE
            binding.llCounselors.visibility = View.VISIBLE
            binding.tvAccountRole.text = "Teacher's Account"
        }

        if (role=="Student"){
            binding.llBookingStudent.visibility = View.VISIBLE
            binding.llMyBookings.visibility = View.VISIBLE
            binding.llCounselors.visibility = View.VISIBLE
            binding.llTodaysAppointment.visibility = View.VISIBLE
            binding.tvAccountRole.text = "Student's Account"
        }

        if (role=="Counselor"){
            binding.llBookingCounselor.visibility = View.VISIBLE
            binding.llMyBookings.visibility = View.VISIBLE
            binding.llTodaysAppointment.visibility = View.VISIBLE
            binding.tvAccountRole.text = "Counselor's Account"
        }

        createNotifChannel()

        val intent=Intent(this,MainActivity::class.java)
        val pendingIntent = TaskStackBuilder.create(this).run {
            addNextIntentWithParentStack(intent)
            getPendingIntent(0,PendingIntent.FLAG_UPDATE_CURRENT)
        }

        val notif = NotificationCompat.Builder(this,CHANNEL_ID)
            .setContentTitle("Sample Title")
            .setContentText("This is sample body notif")
            .setSmallIcon(R.drawable.ic_delete)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .build()

        val notifManger = NotificationManagerCompat.from(this)

        binding.llNotification.setOnClickListener {
            notifManger.notify(NOTIF_ID,notif)
        }
        binding.llNotification.visibility = View.GONE
    }

    private fun createNotifChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, CHANNEL_NAME, NotificationManager.IMPORTANCE_DEFAULT).apply {
                lightColor = Color.BLUE
                enableLights(true)
            }
            val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }
}