package com.thesis.onlinecounseling.booking

import com.google.gson.annotations.SerializedName
import com.thesis.onlinecounseling.models.User

data class StudentRequest(
    @SerializedName("idNumber")
    var idNumber: String,

    @SerializedName("success")
    var success: Boolean = false,

    @SerializedName("student")
    var student: User? = null
)