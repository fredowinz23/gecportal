package com.thesis.onlinecounseling.booking

import com.google.gson.annotations.SerializedName

data class NewBookingRequest(

    @SerializedName("username")
    var username: String = "",

    @SerializedName("purpose")
    var purpose: String = "",

    @SerializedName("appointmentDate")
    var appointmentDate: String = "",

    @SerializedName("appointmentTime")
    var appointmentTime: String = "",

    @SerializedName("appointmentType")
    var appointmentType: String = "",

    @SerializedName("counselorId")
    var counselorId: Int = 0,

    @SerializedName("studentId")
    var studentId: Int = 0,

    @SerializedName("success")
    var success: String = "",

)