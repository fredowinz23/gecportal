<?php
include "../templates/api-header.php";

$BASE_URL = "http://" . $_SERVER['SERVER_NAME'];
$json = array();
$success = false;
$rank = "";
$cart = 0;
if (isset($_POST["appointmentId"])) {
  $appointmentId = $_POST["appointmentId"];
  $success = true;

  $chat_list = array();

  foreach (chat()->list("appointmentId=$appointmentId") as $row) {
    $item = json_decode(json_encode($row), true);
    array_push($chat_list, $item);
  }
}

$json["appointmentId"] = $_POST["appointmentId"];
$json["chat_list"] = $chat_list;
$json["success"] = $success;

echo json_encode($json);
?>
