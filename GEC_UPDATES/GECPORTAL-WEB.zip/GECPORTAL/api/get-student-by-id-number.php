<?php
include "../templates/api-header.php";
include "interface.php";

$json = array();
$success = false;
$response = "";
if (isset($_POST["idNumber"])) {
  $idNumber = $_POST["idNumber"];
  $checkUserExist = user()->count("idNumber='$idNumber'");
  if ($checkUserExist > 0) {
    $user = user()->get("idNumber='$idNumber'");
    $success = true;
    $json["student"] = json_decode(json_encode($user), true);
  }
}

$json["idNumber"] = $_POST["idNumber"];
$json["success"] = $success;


header('Content-Type: application/json; charset=utf-8');
echo json_encode($json);
?>
