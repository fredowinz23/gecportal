<?php
include "../templates/api-header.php";

$BASE_URL = "http://" . $_SERVER['SERVER_NAME'];
$json = array();
$success = false;
$rank = "";
$cart = 0;
if (isset($_POST["username"])) {
  $username = $_POST["username"];
  $counselorId = $_POST["counselorId"];
  $appointmentDate = $_POST["appointmentDate"];
  $user = user()->get("username='$username'");
  $success = true;

  $availability = array();

  $am8 = appointment()->count("counselorId='$counselorId' and appointmentDate='$appointmentDate' and appointmentTime='8:00AM'");
  $am9 = appointment()->count("counselorId='$counselorId' and appointmentDate='$appointmentDate' and appointmentTime='9:00AM'");
  $am10 = appointment()->count("counselorId='$counselorId' and appointmentDate='$appointmentDate' and appointmentTime='10:00AM'");
  $am11 = appointment()->count("counselorId='$counselorId' and appointmentDate='$appointmentDate' and appointmentTime='11:00AM'");
  $pm130 = appointment()->count("counselorId='$counselorId' and appointmentDate='$appointmentDate' and appointmentTime='1:30PM'");
  $pm230 = appointment()->count("counselorId='$counselorId' and appointmentDate='$appointmentDate' and appointmentTime='2:30PM'");
  $pm330 = appointment()->count("counselorId='$counselorId' and appointmentDate='$appointmentDate' and appointmentTime='3:30PM'");
  $pm430 = appointment()->count("counselorId='$counselorId' and appointmentDate='$appointmentDate' and appointmentTime='4:30PM'");

  $availability["slot8am"] = "A";
  $availability["slot9am"] = "A";
  $availability["slot10am"] = "A";
  $availability["slot11am"] = "A";
  $availability["slot130pm"] = "A";
  $availability["slot230pm"] = "A";
  $availability["slot330pm"] = "A";
  $availability["slot430pm"] = "A";

  if ($am8>0) {
    $availability["slot8am"] = "NA";
  }
  if ($am9>0) {
    $availability["slot9am"] = "NA";
  }
  if ($am10>0) {
    $availability["slot10am"] = "NA";
  }
  if ($am11>0) {
    $availability["slot11am"] = "NA";
  }
  if ($pm130>0) {
    $availability["slot130pm"] = "NA";
  }
  if ($pm230>0) {
    $availability["slot230pm"] = "NA";
  }
  if ($pm330>0) {
    $availability["slot330pm"] = "NA";
  }
  if ($pm430>0) {
    $availability["slot430pm"] = "NA";
  }
}

$json["username"] = $_POST["username"];
$json["availability"] = $availability;
$json["success"] = $success;

echo json_encode($json);
?>
