<?php
include "../templates/api-header.php";

$json = array();
$success = false;
$response = "";
if (isset($_POST["appointmentId"])) {
  $appointmentId = $_POST["appointmentId"];
  $success = true;

  $model = appointment();
  $model->obj["report"] = $_POST["report"];
  $model->obj["status"] = "Done";
  $model->update("Id=$appointmentId");
}

$json["appointmentId"] = $_POST["appointmentId"];
$json["report"] = $_POST["report"];
$json["success"] = $success;


header('Content-Type: application/json; charset=utf-8');
echo json_encode($json);
?>
