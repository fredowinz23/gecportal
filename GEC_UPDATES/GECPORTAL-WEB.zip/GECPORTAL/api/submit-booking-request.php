<?php
include "../templates/api-header.php";

$json = array();
$success = false;
$response = "";
if (isset($_POST["username"])) {
  $username = $_POST["username"];
  $user = user()->get("username='$username'");
  $success = true;

  $model = appointment();
  $model->obj["createdBy"] = $user->Id;
  $model->obj["studentId"] = $_POST["studentId"];
  $model->obj["appointmentDate"] = $_POST["appointmentDate"];
  $model->obj["appointmentTime"] = $_POST["appointmentTime"];
  $model->obj["appointmentType"] = $_POST["appointmentType"];
  $model->obj["counselorId"] = $_POST["counselorId"];
  $model->obj["purpose"] = $_POST["purpose"];
  $model->obj["status"] = "Pending";
  $model->obj["dateAdded"] = "NOW()";
  $model->create();
}

$json["username"] = $_POST["username"];
$json["success"] = $success;


header('Content-Type: application/json; charset=utf-8');
echo json_encode($json);
?>
