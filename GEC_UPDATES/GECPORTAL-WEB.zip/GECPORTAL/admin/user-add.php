<?php
$ROOT_DIR="../";
include $ROOT_DIR . "templates/header.php";
$role = $_GET["role"];
$temp_password = rand(100000,999999);
?>

<form action="process.php?action=user-add" enctype="multipart/form-data" method="post">
<div class="card mt-3">
  <div class="card-header">
    <b>Create New <?=$role;?></b>
  </div>
  <div class="card-body">
    <div class="row">
      <div class="col-lg-6">
        <b class="form-label">Username</b> <span style="color:red;"><?=$error;?></span>
        <input type="text" name="username" class="form-control" required>
      </div>
      <div class="col-lg-6">
        <b class="form-label">Temporary Password</b>
        <input type="hidden" name="password" value="<?=$temp_password;?>">
        <input type="text" class="form-control" value="<?=$temp_password;?>" disabled>
      </div>
      <div class="col-lg-4">
        <b class="form-label">First Name</b>
        <input type="text" name="firstName" class="form-control" required>
      </div>

      <div class="col-lg-4">
        <b class="form-label">Last Name</b>
        <input type="text" name="lastName" class="form-control" required>
      </div>
      <div class="col-lg-4">
        <b class="form-label">Role</b>
        <input type="text" name="role" class="form-control" value="<?=$role;?>" disabled>
        <input type="hidden" name="role" class="form-control" value="<?=$role;?>" required>
      </div>
  </div>
  </div>
  <div class="card-footer">
    <button type="submit" class="btn btn-primary">Add</button>
  </div>
</div>
</form>

<?php include $ROOT_DIR . "templates/footer.php"; ?>
