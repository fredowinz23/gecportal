<?php
$ROOT_DIR="../";
include $ROOT_DIR . "templates/header.php";

$word_list = sensetive_words()->list("Id>0 order by word");

?>
<br><br><br>
  <div class="row">
    <form action="process.php?action=word-add" method="post">
      <div class="col-12 text-left">
          <div class="input-group mb-3">
            <input type="text" name="word" class="form-control" placeholder="New Sensetive Word" required>
            <div class="input-group-append">
              <button class="btn btn-primary" type="submit">Add</button>
            </div>
          </div>
      </div>
    </form>
  </div>

<br>

<table class="table">
  <tr>
    <th>#</th>
    <th>Word</th>
    <th width="100">Action</th>
  </tr>

  <?php
  $count = 0;
   foreach ($word_list as $row):
     $count += 1;
     ?>
    <tr>
      <td><?=$count;?></td>
      <td><?=$row->word;?></td>
      <td><a href="process.php?action=word-delete&Id=<?=$row->Id;?>" class="btn btn-danger btn-sm">Delete</a></td>

    </tr>
  <?php endforeach; ?>

</table>

<?php include $ROOT_DIR . "templates/footer.php"; ?>
