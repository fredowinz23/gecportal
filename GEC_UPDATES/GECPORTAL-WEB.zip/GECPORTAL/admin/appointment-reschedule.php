<?php
$ROOT_DIR="../";
include $ROOT_DIR . "templates/header.php";

$Id = get_query_string("Id", "");
?>

<form action="process.php?action=appointment-reschedule" enctype="multipart/form-data" method="post">
<div class="card mt-3">
  <div class="card-header">
    <b>Reschedule Appointment</b>
  </div>
  <div class="card-body">
    <div class="row">
      <div class="col-lg-6">
        <b class="form-label">Appointment Date</b>
        <input type="date" name="appointmentDate" class="form-control" required>
        <input type="hidden" name="Id" value="<?=$Id?>">
      </div>
        <div class="col-lg-6">
          <b class="form-label">Appointment Time</b>
          <select class="form-control" name="appointmentTime" required>
            <option value="">--Select--</option>
            <option>8:00AM</option>
            <option>9:00AM</option>
            <option>10:00AM</option>
            <option>11:00AM</option>
            <option>1:30PM</option>
            <option>2:30PM</option>
            <option>3:30PM</option>
            <option>4:30PM</option>
          </select>
        </div>
  </div>
  </div>
  <div class="card-footer">
    <button type="submit" class="btn btn-primary">Save and approve</button>
  </div>
</div>
</form>

<?php include $ROOT_DIR . "templates/footer.php"; ?>
