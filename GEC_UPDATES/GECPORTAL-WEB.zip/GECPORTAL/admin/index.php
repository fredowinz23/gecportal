<?php
  $ROOT_DIR="../";
  include $ROOT_DIR . "templates/header.php";

?>

<br><br><br>
<center>
<h2>Online Counseling System</h2>
</center>
<br><br>



<?php include $ROOT_DIR . "templates/footer.php"; ?>
