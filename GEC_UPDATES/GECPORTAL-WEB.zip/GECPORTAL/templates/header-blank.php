<?php
session_start();
include_once($ROOT_DIR . "config/database.php");
include_once($ROOT_DIR . "config/Models.php");
?>

<html dir="ltr" lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="robots" content="noindex,nofollow" />
    <title>Online Counseling System</title>
    <!-- Custom CSS -->
    <link href="<?=$ROOT_DIR;?>templates/assets/libs/flot/css/float-chart.css" rel="stylesheet" />
    <!-- Custom CSS -->
    <link href="<?=$ROOT_DIR;?>templates/dist/css/style.min.css" rel="stylesheet" />
  </head>

  <body>

      <div class="page-wrapper" style="background:white !important;">
        <div class="container">
