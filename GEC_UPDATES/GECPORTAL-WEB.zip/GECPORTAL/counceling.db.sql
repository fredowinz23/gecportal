﻿# Host: localhost  (Version 5.5.5-10.1.34-MariaDB)
# Date: 2023-05-24 16:33:08
# Generator: MySQL-Front 6.1  (Build 1.26)


#
# Structure for table "appointment"
#

DROP TABLE IF EXISTS `appointment`;
CREATE TABLE `appointment` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `createdBy` int(11) DEFAULT NULL,
  `studentId` int(11) DEFAULT NULL,
  `appointmentDate` date DEFAULT NULL,
  `status` varchar(30) DEFAULT NULL,
  `appointmentType` varchar(255) DEFAULT NULL,
  `dateAdded` date DEFAULT NULL,
  `appointmentTime` varchar(10) DEFAULT NULL,
  `purpose` text,
  `counselorId` int(11) DEFAULT NULL,
  `zoomLink` varchar(255) DEFAULT NULL,
  `report` text,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

#
# Data for table "appointment"
#

INSERT INTO `appointment` VALUES (1,6,6,'2023-05-17','Done','Zoom','2023-05-17','8:00AM','sdfdsfdsffds',2,'kjhkjhkjhkjhkj@dsfdsfsd.fdsfds','kjkjhkjh\ndsfdsfdsl;kfdsl;fkds\nfdsf;ldsfkds;lfkdsf\ndsfkl;dsfds;lfkdsf\ndsfds;lfkds;lfkdsf\nsfsdfsdf\ndsf\nsdfds\nf\ndsf\ndsf\nsdf\nsdf\nsfsd\nff\nsdf\nsdf\ndsf'),(2,6,6,'2023-05-25','Done','Chat','2023-05-17','11:00AM','jkhkjhk',2,NULL,'This is a nice conve'),(3,6,6,'2023-05-17','Pending','Zoom','2023-05-17','11:00AM','Killing me softly',2,'https://meet.google.com/oke-cpsh-tkk',NULL),(4,6,6,'2023-05-17','Pending','Zoom','2023-05-17','10:00AM','dfdf',2,NULL,NULL),(5,6,6,'2023-05-18','Pending','Chat','2023-05-18','11:00AM','dsfsdfds',3,NULL,NULL),(6,2,2,'2023-05-18','Pending','Chat','2023-05-18','1:30PM','jhjhhj',3,NULL,NULL),(7,6,6,'2023-05-19','Pending','Zoom','2023-05-19','9:00AM','lkhjljlk',2,'https://meet.google.com/oke-cpsh-tkk',NULL),(8,4,0,'2023-05-19','Pending','Chat','2023-05-20','11:00AM','sddfdsfdsfdsf',3,NULL,NULL),(9,4,6,'2023-05-19','Pending','Zoom','2023-05-20','1:30PM','dsfsdfdsf',3,NULL,NULL),(10,2,6,'2023-05-20','Approved','Chat','2023-05-20',NULL,NULL,NULL,NULL,NULL),(11,4,6,'2023-05-22','Pending','Chat','2023-05-22','1:30PM','Fredowinz23 aaa',4,NULL,NULL),(12,4,6,'2023-05-22','Pending','Chat','2023-05-22','11:00AM','Ciagar hehehehe',4,NULL,NULL),(13,4,6,'2023-05-22','Pending','Face to Face','2023-05-22','2:30PM','aa aa',4,NULL,NULL),(14,4,6,'2023-05-22','Pending','Face to Face','2023-05-22','10:00AM','Testing',4,NULL,NULL),(15,4,6,'2023-05-23','Pending','Chat','2023-05-23','9:00AM','sdfdsfds',4,NULL,NULL),(16,2,6,'2023-05-23','Approved','Chat','2023-05-23',NULL,NULL,NULL,NULL,NULL),(17,2,6,'2023-05-23','Approved','Chat','2023-05-23',NULL,NULL,NULL,NULL,NULL),(18,2,6,'2023-05-17','Approved','Chat','2023-05-23','1:30PM','Aaaaaa aaaaa aaaa',NULL,NULL,NULL),(19,6,6,'2023-05-23','Pending','Chat','2023-05-23','10:00AM','wala lang',2,NULL,NULL);

#
# Structure for table "chat"
#

DROP TABLE IF EXISTS `chat`;
CREATE TABLE `chat` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `appointmentId` int(11) DEFAULT NULL,
  `senderId` int(11) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `time` time DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

#
# Data for table "chat"
#

INSERT INTO `chat` VALUES (1,6,3,'dsfdsfdsf',NULL),(2,6,6,'sample','13:33:42'),(3,6,6,'how are you today?','13:33:50'),(4,6,2,'naano ka','13:33:50'),(5,6,6,'ok lang ko','13:41:42'),(6,6,2,'Hello','18:02:29'),(7,6,2,'how are you today?','18:02:54'),(8,6,2,'how are you today?','18:03:18'),(9,6,2,'','18:03:23'),(10,6,5,'live na',NULL),(11,6,2,'how are you','19:55:05'),(12,6,2,'testint','19:56:25'),(13,6,2,'nice kay nagadula na nag akon nga chat','19:56:37'),(14,2,6,'hi','17:19:47'),(15,2,2,'ow are you','13:51:09'),(16,19,2,'hi fred','15:24:27'),(17,19,6,'kumusta?','15:24:36'),(18,19,2,'ok lang','15:24:48'),(19,2,2,'are you good','08:36:54'),(20,2,2,'do you have a problem?','08:37:01');

#
# Structure for table "sensetive_words"
#

DROP TABLE IF EXISTS `sensetive_words`;
CREATE TABLE `sensetive_words` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `word` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

#
# Data for table "sensetive_words"
#

INSERT INTO `sensetive_words` VALUES (4,'sample'),(5,'Kill'),(6,'Ana'),(7,'baka');

#
# Structure for table "user"
#

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `Id` tinyint(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `password` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `firstName` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastName` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'Inactive',
  `role` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dateAdded` date DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isDeleted` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'false',
  `idNumber` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `collegeId` int(11) DEFAULT NULL,
  `courseId` int(11) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPACT;

#
# Data for table "user"
#

INSERT INTO `user` VALUES (1,'admin','1234','Juan','De la cruz','Active','Admin',NULL,NULL,NULL,'false',NULL,NULL,NULL),(2,'coun1','1234','aa','aa','Active','Counselor','2023-05-17',NULL,NULL,'false',NULL,NULL,NULL),(3,'count2','808500','ben','tong','Inactive','Counselor','2023-05-17',NULL,NULL,'false',NULL,NULL,NULL),(4,'teacher1','1234','tea','cher','Active','Teacher','2023-05-17',NULL,NULL,'false',NULL,NULL,NULL),(5,'teacher2','747192','tea','cher2','Inactive','Teacher','2023-05-17',NULL,NULL,'false',NULL,NULL,NULL),(6,'student1','1234','john','Rick','Active','Student','2023-05-17',NULL,NULL,'false','0522612',NULL,NULL),(7,'student2','122703','stu','dent2','Inactive','Student','2023-05-17',NULL,NULL,'false',NULL,NULL,NULL);
