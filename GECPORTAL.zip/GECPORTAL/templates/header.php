<?php
session_start();
include_once($ROOT_DIR . "config/database.php");
include_once($ROOT_DIR . "config/Models.php");
$userSession = $_SESSION["user_session"];
$username = $userSession["username"];
?>

<style media="screen">
  .gec-theme{
    background: #eea512 !important;
  }
  .gec-theme a{
    color: white !important;
  }
  .logo-color{
    color: #eea512 !important;
  }

</style>

<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>GEC Portal - Online Counseling System</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?=$ROOT_DIR;?>templates/assets/vendor/bootstrap/css/bootstrap.min.css">
    <link href="<?=$ROOT_DIR;?>templates/assets/vendor/fonts/circular-std/style.css" rel="stylesheet">
    <link rel="stylesheet" href="<?=$ROOT_DIR;?>templates/assets/libs/css/style.css">
    <link rel="stylesheet" href="<?=$ROOT_DIR;?>templates/assets/vendor/fonts/fontawesome/css/fontawesome-all.css">

    <!-- for data tables -->
    <link rel="stylesheet" type="text/css" href="<?=$ROOT_DIR;?>templates/assets/vendor/datatables/css/dataTables.bootstrap4.css">
    <link rel="stylesheet" type="text/css" href="<?=$ROOT_DIR;?>templates/assets/vendor/datatables/css/buttons.bootstrap4.css">
    <link rel="stylesheet" type="text/css" href="<?=$ROOT_DIR;?>templates/assets/vendor/datatables/css/select.bootstrap4.css">
    <link rel="stylesheet" type="text/css" href="<?=$ROOT_DIR;?>templates/assets/vendor/datatables/css/fixedHeader.bootstrap4.css">


  <!-- for calendar -->

    <link href='<?=$ROOT_DIR;?>templates//assets/vendor/full-calendar/css/fullcalendar.css' rel='stylesheet' />
    <link href='<?=$ROOT_DIR;?>templates//assets/vendor/full-calendar/css/fullcalendar.print.css' rel='stylesheet' media='print' />
</head>


<body>
    <!-- ============================================================== -->
    <!-- main wrapper -->
    <!-- ============================================================== -->
    <div class="dashboard-main-wrapper">
        <!-- ============================================================== -->
        <!-- navbar -->
        <!-- ============================================================== -->
        <div class="dashboard-header">
            <nav class="navbar navbar-expand-lg bg-white fixed-top">
                <a class="navbar-brand logo-color" href="index.php">GEC PORTAL</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse " id="navbarSupportedContent">
                    <ul class="navbar-nav ml-auto navbar-right-top">
                        <li class="nav-item">
                            <div id="custom-search" class="top-search-bar">
                                <input class="form-control" type="text" placeholder="Search..">
                            </div>
                        </li>
                        <li class="nav-item dropdown nav-user">
                            <a class="nav-link nav-user-img" href="#" id="navbarDropdownMenuLink2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fas fa-fw fa-th"></i></a>
                            <div class="dropdown-menu dropdown-menu-right nav-user-dropdown" aria-labelledby="navbarDropdownMenuLink2">
                                <div class="nav-user-info">
                                    <h5 class="mb-0 text-white nav-user-name"><?=$account->firstName;?> <?=$account->lastName;?> </h5>
                                    <span class="status"></span><span class="ml-2">Available</span>
                                </div>
                                <a class="dropdown-item" href="#"><i class="fas fa-user mr-2"></i>Account</a>
                                <a class="dropdown-item" href="#"><i class="fas fa-cog mr-2"></i>Setting</a>
                                <a class="dropdown-item" href="../auth/process.php?action=user-logout"><i class="fas fa-power-off mr-2"></i>Logout</a>
                            </div>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
        <!-- ============================================================== -->
        <!-- end navbar -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- left sidebar -->
        <!-- ============================================================== -->
        <div class="nav-left-sidebar gec-theme">
            <div class="menu-list">
                <nav class="navbar navbar-expand-lg navbar-light">
                    <a class="d-xl-none d-lg-none" href="#">Dashboard</a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarNav">
                        <ul class="navbar-nav flex-column">

                          <li class="nav-divider">
                              Options
                          </li>

                          <li class="nav-item"><a href="index.php" class="nav-link">Home</a></li>


                          <?php if ($userSession["role"]=="Admin"): ?>
                              <li class="nav-item"><a href="../admin/users.php?role=Admin" class="nav-link">Accounts</a></li>
                          <?php endif; ?>

                          <?php if ($userSession["role"]=="Counselor"): ?>

                                <li class="nav-item"><a href="appointments.php" class="nav-link">Appointments</a></li>

                                <li class="nav-item"><a href="appointment-add.php" class="nav-link">New Student Appointment</a></li>


                                <li class="nav-item"><a href="sensetive-words.php" class="nav-link">Sensetive Words</a></li>
                          <?php endif; ?>

                        <li class="nav-item"><a href="../auth/login.php" class="nav-link">Logout</a></li>
                        </ul>
                    </div>
                </nav>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- end left sidebar -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- wrapper  -->
        <!-- ============================================================== -->
        <div class="dashboard-wrapper">
    <div class="container-fluid dashboard-content">
