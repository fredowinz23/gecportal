<?php
include "../templates/api-header.php";

$json = array();
$success = false;
$response = "";
if (isset($_POST["username"])) {
  $username = $_POST["username"];
  $user = user()->get("username='$username'");
  $success = true;

  $model = chat();
  $model->obj["senderId"] = $user->Id;
  $model->obj["appointmentId"] = $_POST["appointmentId"];
  $model->obj["message"] = $_POST["message"];
  $model->obj["time"] = "NOW()";
  $model->create();
}

$json["username"] = $_POST["username"];
$json["appointmentId"] = $_POST["appointmentId"];
$json["message"] = $_POST["message"];
$json["success"] = $success;


header('Content-Type: application/json; charset=utf-8');
echo json_encode($json);
?>
