<?php
include "../templates/api-header.php";
include "interface.php";

$json = array();
$success = false;
$response = "";
if (isset($_POST["username"])) {
  $username = $_POST["username"];
  $user = user()->get("username='$username'");
  $success = true;

  $model = user();
  $model->obj["address"] =  $_POST["address"];
  $model->obj["course"] =  $_POST["course"];
  $model->obj["department"] =  $_POST["department"];
  $model->obj["idNumber"] =  $_POST["idNumber"];
  $model->obj["phone"] =  $_POST["phone"];
  $model->obj["email"] =  $_POST["email"];
  $model->update("Id=$user->Id");

}

$json["username"] = $_POST["username"];
$json["success"] = $success;


header('Content-Type: application/json; charset=utf-8');
echo json_encode($json);
?>
