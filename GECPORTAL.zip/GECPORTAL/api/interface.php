<?php

function cart_interface($object){
    $user = user()->get("Id=$object->userId");
    $userObject = user_interface($user);

    $item = item()->get("Id=$object->itemId");
    $itemObject = item_interface($item);

    $category = category()->get("Id=$object->customizedCatId");
    $categoryObject = category_interface($category);

    $response = array();
    $response["id"] = $object->Id;
    $response["quantity"] = $object->quantity;
    $response["dateAdded"] = $object->dateAdded;
    $response["isCustomized"] = $object->isCustomized;

    $response["user"] = $userObject;
    $response["product"] = $itemObject;
    $response["customizedCatId"] = $categoryObject;
    return $response;
}


function reservation_interface($object){
    $user = user()->get("Id=$object->userId");
    $userObject = user_interface($user);

    $item = item()->get("Id=$object->itemId");
    $itemObject = item_interface($item);

    $response = array();
    $response["id"] = $object->Id;
    $response["quantity"] = $object->quantity;
    $response["dateAdded"] = $object->dateAdded;

    $response["user"] = $userObject;
    $response["product"] = $itemObject;
    return $response;
}


function category_interface($object){
    $response = array();
    $response["id"] = $object->Id;
    $response["name"] = $object->name;
    $response["description"] = $object->description;
    return $response;
}

function item_interface($object){
  $BASE_URL = "http://" . $_SERVER['SERVER_NAME'];
  $subCategory = sub_category()->get("Id=$object->subCategoryId");
  $subCategoryObject = sub_category_interface($subCategory);

  $response = array();
  $response["id"] = $object->Id;
  $response["name"] = $object->name;
  $response["description"] = $object->description;
  $response["price"] = $object->price;
  $response["quantity"] = $object->quantity;
  $response["dateAdded"] = $object->dateAdded;
  $response["image"] = $BASE_URL . "/cyclecircle/media/" . $object->image;
  $response["status"] = $object->status;
  $response["subCategory"] = $subCategoryObject;
  return $response;
}


function order_item_interface($object){
    $item = item()->get("Id=$object->itemId");
    $itemObject = item_interface($item);

    $response = array();
    $response["id"] = $object->Id;
    $response["orderNumber"] = $object->orderNumber;
    $response["quantity"] = $object->quantity;

    $response["item"] = $itemObject;
    return $response;
}


function order_main_interface($object){
    $user = user()->get("Id=$object->userId");
    $userObject = user_interface($user);

    $response = array();
    $response["id"] = $object->Id;
    $response["orderNumber"] = $object->orderNumber;
    $response["dateAdded"] = $object->dateAdded;
    $response["status"] = $object->status;
    $response["method"] = $object->method;
    $response["isCustomized"] = $object->isCustomized;
    $response["address"] = $object->address;

    $response["user"] = $userObject;
    return $response;
}


function sub_category_interface($object){
  $category = category()->get("Id=$object->categoryId");
  $categoryObject = category_interface($category);

  $response = array();
  $response["id"] = $object->Id;
  $response["name"] = $object->name . " (" . $object->type . ")";
  $response["description"] = $object->description;
  $response["category"] = $categoryObject;
  return $response;
}


function user_interface($object){
    $response = array();
    $response["id"] = $object->Id;
    $response["username"] = $object->username;
    $response["email"] = $object->email;
    $response["phone"] = $object->phone;
    $response["firstName"] = $object->firstName;
    $response["lastName"] = $object->lastName;
    $response["status"] = $object->status;
    return $response;
}

?>
