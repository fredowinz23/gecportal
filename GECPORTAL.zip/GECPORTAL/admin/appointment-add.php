<?php
$ROOT_DIR="../";
include $ROOT_DIR . "templates/header.php";

$student_list = user()->list("role='Student'");
?>

<form action="process.php?action=appointment-add" enctype="multipart/form-data" method="post">
<div class="card mt-3">
  <div class="card-header">
    <b>Create New Appointment</b>
  </div>
  <div class="card-body">
    <div class="row">
      <div class="col-lg-6">
        <b class="form-label">Appointment Date</b>
        <input type="date" name="appointmentDate" class="form-control" required>
      </div>
        <div class="col-lg-6">
          <b class="form-label">Appointment Time</b>
          <select class="form-control" name="appointmentTime" required>
            <option value="">--Select--</option>
            <option>8:00AM</option>
            <option>9:00AM</option>
            <option>10:00AM</option>
            <option>11:00AM</option>
            <option>1:30PM</option>
            <option>2:30PM</option>
            <option>3:30PM</option>
            <option>4:30PM</option>
          </select>
        </div>
      <div class="col-lg-6">
        <b class="form-label">Student</b>
        <select class="form-control" name="studentId" required>
          <option value="">--Select--</option>
          <?php foreach ($student_list as $row): ?>
            <option value="<?=$row->Id?>"><?=$row->firstName;?> <?=$row->lastName;?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="col-lg-6 mt-3">
        <b class="form-label">Appointment Type</b>
        <select class="form-control" name="appointmentType" required>
          <option value="">--Select--</option>
          <option>Face to face</option>
          <option>Chat</option>
          <option>Zoom</option>
        </select>
      </div>
      <div class="col-lg-12 mt-3">
        <b class="form-label">Purpose</b>
        <textarea name="purpose" class="form-control" required></textarea>
      </div>

  </div>
  </div>
  <div class="card-footer">
    <button type="submit" class="btn btn-primary">Add</button>
  </div>
</div>
</form>

<?php include $ROOT_DIR . "templates/footer.php"; ?>
