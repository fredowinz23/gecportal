<?php
  $ROOT_DIR="../";
  include $ROOT_DIR . "templates/header.php";

  $word_list = sensetive_words()->list("Id>0 order by word");
?>

<style media="screen">
  .high-level{
    background: red;
    color: white;
  }
  .medium-level{
    background: #fc7f03;
    color: white;
  }
  .low-level{
    background: #f5de0c;
    color: white;
  }
</style>

<br><br><br>
  <div class="row">
    <form action="process.php?action=word-add" method="post">
      <div class="col-12 text-left">
          <div class="input-group mb-3">
            <input type="text" name="word" class="form-control" placeholder="New Sensetive Word" required>
            <select class="form-control" name="level" required>
              <option value="">--Select Level--</option>
              <option>High</option>
              <option>Medium</option>
              <option>Low</option>
            </select>
            <div class="input-group-append">
              <button class="btn btn-primary" type="submit">Add</button>
            </div>
          </div>
      </div>
    </form>
  </div>

<br>

<table class="table">
  <tr>
    <th>#</th>
    <th>Word</th>
    <th>Level</th>
    <th width="100">Action</th>
  </tr>

  <?php
  $count = 0;
   foreach ($word_list as $row):
     $count += 1;
     ?>
     <?php if ($row->level=="High"): ?>
      <tr class="high-level">
      <?php elseif ($row->level=="Medium"): ?>
       <tr class="medium-level">
     <?php elseif ($row->level=="Low"): ?>
      <tr class="low-level">
      <?php else: ?>
       <tr>
     <?php endif; ?>
      <td><?=$count;?></td>
      <td><?=$row->word;?></td>
      <td><?=$row->level;?></td>
      <td><a href="process.php?action=word-delete&Id=<?=$row->Id;?>" class="btn btn-danger btn-sm">Delete</a></td>
    </tr>
  <?php endforeach; ?>

</table>

<?php include $ROOT_DIR . "templates/footer.php"; ?>
