<?php
$ROOT_DIR="../";
include $ROOT_DIR . "templates/header.php";

$Id = get_query_string("Id", "");
?>

<form action="process.php?action=add-zoom-link" enctype="multipart/form-data" method="post">
<div class="card mt-3">
  <div class="card-header">
    <b>Add Zoom Link</b>
  </div>
  <div class="card-body">
    <div class="row">
      <div class="col-lg-6">
        <b class="form-label">Zoom Link</b>
        <input type="text" name="zoomLink" class="form-control" required>
        <input type="hidden" name="Id" value="<?=$Id?>" required>
      </div>
  </div>
  </div>
  <div class="card-footer">
    <button type="submit" class="btn btn-primary">Add</button>
  </div>
</div>
</form>

<?php include $ROOT_DIR . "templates/footer.php"; ?>
