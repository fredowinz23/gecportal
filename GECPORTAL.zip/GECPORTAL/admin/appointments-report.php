<?php
$ROOT_DIR="../";
include $ROOT_DIR . "templates/header.php";

$type = get_query_string("type", "pending");
$word_list = sensetive_words()->list();
$sensitiveChecker = true;
$sensetiveFilter = false;

$totalResult = get_total_appointment_by_type($type);

if ($type=="pending") {
  $appointment_list = appointment()->list("status='Pending'");
  $title = "Pending Appointments";
}
if ($type=="this-month") {
  $thisMonth = date("Y-m");
  $appointment_list = appointment()->list("appointmentDate like '$thisMonth%'");
  $title = "This Month Appointment";
}
if ($type=="pending-sensitive") {
  $appointment_list = appointment()->list("status='Pending'");
  $sensetiveFilter = true;
  $title = "Pending Appointments with sensetive words";
}
if ($type=="total-sensetive") {
  $appointment_list = appointment()->list();
  $sensetiveFilter = true;
  $title = "Total Appointments with sensetive words";
}

?>

<style media="screen">
  .high-level{
    background: red;
    color: white;
  }
  .medium-level{
    background: #fc7f03;
    color: white;
  }
  .low-level{
    background: #f5de0c;
    color: white;
  }
</style>


<br><br>
<h1><?=$title;?></h1>
<b>Total Result: <?=$totalResult;?></b>
<table class="table">
  <tr>
    <th>#</th>
    <th>Date</th>
    <th>Student</th>
    <th>Sensetive Words</th>
    <th width="100">Action</th>
  </tr>

  <?php
  $count = 0;
  $level = "";
  $isSensetive = false;
   foreach ($appointment_list as $row):
     $student = user()->get("Id=$row->studentId");
     $count += 1;
     $isSensetive = false;
     $level = "";

     $words = array();
     foreach ($word_list as $word) {
       if(strpos($row->purpose, $word->word) !== false){
            array_push($words, $word->word);
            $level = $word->level;
            $isSensetive = true;
        }
     }

     if ($sensetiveFilter) {
       $sensitiveChecker = $isSensetive;
     }

     ?>
     <?php if ($sensitiveChecker): ?>

     <?php if ($level=="High"): ?>
      <tr class="high-level">
      <?php elseif ($level=="Medium"): ?>
       <tr class="medium-level">
     <?php elseif ($level=="Low"): ?>
      <tr class="low-level">
      <?php else: ?>
       <tr>
     <?php endif; ?>
      <td><?=$count;?></td>
      <td><?=$row->appointmentDate;?></td>
      <td><?=$student->firstName;?> <?=$student->lastName;?></td>
      <td><?=implode(', ', $words);?></td>
      <td><a href="appointment-detail.php?Id=<?=$row->Id;?>" class="btn btn-primary btn-sm">View</a></td>

    </tr>

  <?php endif; ?>
  <?php endforeach; ?>

</table>


<?php include $ROOT_DIR . "templates/footer.php"; ?>
