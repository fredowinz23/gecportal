<?php
  $ROOT_DIR="../";
  include $ROOT_DIR . "templates/header.php";
  $pending = get_total_appointment_by_type("pending");
  $thisMonth = get_total_appointment_by_type("this-month");
  $pendingSensetive = get_total_appointment_by_type("pending-sensitive");
  $totalSensetive = get_total_appointment_by_type("total-sensetive");

?>

<style media="screen">
  .total-number{
    color: white;
  }
  .card{
    color: white;
    cursor: pointer;
  }
  .card:hover{
    background: gray !important;
  }
</style>

<br><br><br>
<center>
<h2>GEC Portal - Online Counseling System</h2>
</center>
<br><br>

<div class="row">
  <div class="col-3">
    <div class="card bg-info" onclick="location.href='appointments-report.php?type=pending'">
      <div class="card-body">
        <h1 class="total-number"><?=$pending;?></h1>
        <hr>
        Pending Appointments
      </div>
    </div>
  </div>

  <div class="col-3">
    <div class="card bg-primary" onclick="location.href='appointments-report.php?type=this-month'">
      <div class="card-body">
        <h1 class="total-number"><?=$thisMonth;?></h1>
        <hr>
        Total Appointments This month
      </div>
    </div>
  </div>


  <div class="col-3">
    <div class="card bg-danger" onclick="location.href='appointments-report.php?type=pending-sensitive'">
      <div class="card-body">
        <h1 class="total-number"><?=$pendingSensetive;?></h1>
        <hr>
        Pending Appointments with Sensitive words
      </div>
    </div>
  </div>


  <div class="col-3">
    <div class="card bg-warning" onclick="location.href='appointments-report.php?type=total-sensetive'">
      <div class="card-body">
        <h1 class="total-number"><?=$totalSensetive;?></h1>
        <hr>
        Total Appointments with Sensitive words
      </div>
    </div>
  </div>
</div>



<?php include $ROOT_DIR . "templates/footer.php"; ?>
