<?php
session_start();
require_once '../config/database.php';
require_once '../config/Models.php';

$action = $_GET['action'];

switch ($action) {

	case 'user-add' :
		user_add();
		break;

	case 'word-add' :
		word_add();
		break;

	case 'word-delete' :
		word_delete();
		break;

	case 'appointment-add' :
		appointment_add();
		break;

	case 'appointment-reschedule' :
		appointment_reschedule();
		break;

	case 'add-zoom-link' :
		add_zoom_link();
		break;


	case 'change-app-status' :
		change_app_status();
		break;

	default :
}

function word_add(){

	$model = sensetive_words();
	$model->obj["word"] = $_POST["word"];
	$model->obj["level"] = $_POST["level"];
	$model->create();

	// print_r($_POST["word"]);
	header('Location: sensetive-words.php');
}

function word_delete(){

	$Id = $_GET["Id"];
	sensetive_words()->delete("Id=$Id");

	// print_r($_POST["word"]);
	header('Location: sensetive-words.php');
}

function change_app_status(){

	$Id = $_GET["Id"];
	$model = appointment();
	$model->obj["status"] = $_GET["status"];
	$model->update("Id=$Id");

	header('Location: appointment-detail.php?Id=' . $Id);
}

function add_zoom_link(){

	$Id = $_POST["Id"];
	$model = appointment();
	$model->obj["zoomLink"] = $_POST["zoomLink"];
	$model->update("Id=$Id");

	header('Location: appointment-detail.php?Id=' . $Id);
}

function appointment_add(){

	$model = appointment();
	$model->obj["createdBy"] = $_SESSION["user_session"]["Id"];
	$model->obj["studentId"] = $_POST["studentId"];
	$model->obj["appointmentTime"] = $_POST["appointmentTime"];
	$model->obj["purpose"] = $_POST["purpose"];
	$model->obj["appointmentDate"] = $_POST["appointmentDate"];
	$model->obj["appointmentType"] = $_POST["appointmentType"];
	$model->obj["status"] = "Approved";
	$model->obj["dateAdded"] = "NOW()";
	$model->create();

	header('Location: appointments.php');
}

function appointment_reschedule(){

	$Id = $_POST["Id"];
	$model = appointment();
	$model->obj["appointmentTime"] = $_POST["appointmentTime"];
	$model->obj["appointmentDate"] = $_POST["appointmentDate"];
	$model->obj["status"] = "Approved";
	$model->update("Id=$Id");

	header('Location: appointment-detail.php?Id=' . $Id);
}


function user_add(){

	$username = $_POST["username"];
	$checkUser = user()->count("username='$username'");

	if ($checkUser>=1) {
		header('Location: user-add.php?role=' . $_POST["role"] . '&error=Username Already Exists');
	}
	else{
			$model = user();
			$model->obj["username"] = $_POST["username"];
			$model->obj["firstName"] = $_POST["firstName"];
			$model->obj["role"] = $_POST["role"];
			$model->obj["lastName"] = $_POST["lastName"];
			$model->obj["password"] = $_POST["password"];
			$model->obj["dateAdded"] = "NOW()";
			$model->create();
			header('Location: users.php?role=' . $_POST["role"]);
	}
}
