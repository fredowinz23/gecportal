<?php
  $ROOT_DIR="../";
  include $ROOT_DIR . "templates/header.php";
  $Id = get_query_string("Id", "");
  $app = appointment()->get("Id=$Id");
  $user = user()->get("Id=$app->studentId");
?>

<style media="screen">
  .form-label{
    font-weight: bold;
    color: blue;
  }
  .form-value{
    font-size: 27px;
    margin-left:20px;
  }
</style>

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Confirmation Dialog</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        Are you sure you want to reschedule this appointment?
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">No</button>
        <a href="appointment-reschedule.php?Id=<?=$Id;?>" class="btn btn-primary">Yes</a>
      </div>
    </div>
  </div>
</div>

<br><br><br>
<a href="appointments.php" class="btn btn-warning mb-2">Back</a>

<div class="card" style="min-height:300px;">
  <div class="card-body">
    <div class="row">
      <div class="col-6">
        <div class="form-label">NAME:</div>
        <div class="form-value"><?=$user->firstName;?> <?=$user->lastName;?></div>
          <br>
        <div class="form-label">DATE:</div>
        <div class="form-value"><?=$app->appointmentDate;?></div>
          <br>
        <div class="form-label">TIME:</div>
        <div class="form-value"><?=$app->appointmentTime;?></div>
      </div>
      <div class="col-6">

        <div class="form-label">TYPE:</div>
        <div class="form-value"><?=$app->appointmentType;?></div>
        <?php if ($app->appointmentType=="Zoom"): ?>
          <?php if ($app->zoomLink): ?>
            Link: <?=$app->zoomLink;?> <br>
          <?php endif; ?>
          <a href="add-zoom-link.php?Id=<?=$app->Id;?>">Add Zoom Link</a>
        <?php endif; ?>
        <br>
        <br>
          <div class="form-label">STATUS:</div>
          <div class="form-value"><?=$app->status;?></div>
        <br>
          <div class="form-label">PURPOSE:</div>
          <div class="form-value"><?=$app->purpose;?></div>
      </div>
      <div class="col-12 mt-3">
        <hr>
        <?php if ($app->status=="Pending"): ?>
          <a href="process.php?action=change-app-status&status=Approved&Id=<?=$Id;?>" class="btn btn-primary">Approve</a>
          <a href="" class="btn btn-warning" data-toggle="modal" data-target="#exampleModal">Reschedule</a>
        <?php else: ?>
          <?php if ($app->status=="Approved"): ?>
            <a href="process.php?action=change-app-status&status=Done&Id=<?=$Id;?>" class="btn btn-primary">Done</a>
            <a href="process.php?action=change-app-status&status=Canceled&Id=<?=$Id;?>" class="btn btn-danger">Cancel</a>
            <a href="process.php?action=change-app-status&status=Pending&Id=<?=$Id;?>" class="btn btn-warning">Change?</a>
            <?php else: ?>
              <a href="process.php?action=change-app-status&status=Pending&Id=<?=$Id;?>" class="btn btn-warning">Change?</a>
          <?php endif; ?>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>

<?php include $ROOT_DIR . "templates/footer.php"; ?>
