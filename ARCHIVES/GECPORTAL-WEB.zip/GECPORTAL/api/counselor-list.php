<?php
include "../templates/api-header.php";

$BASE_URL = "http://" . $_SERVER['SERVER_NAME'];
$json = array();
$success = false;
$rank = "";
$cart = 0;
if (isset($_POST["username"])) {
  $username = $_POST["username"];
  $user = user()->get("username='$username'");
  $success = true;

  $counselor_list = array();

  foreach (user()->list("role='Counselor'") as $row) {
    $item = json_decode(json_encode($row), true);
    array_push($counselor_list, $item);
  }
}

$json["username"] = $_POST["username"];
$json["counselor_list"] = $counselor_list;
$json["success"] = $success;

echo json_encode($json);
?>
