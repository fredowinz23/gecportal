<?php
include "../templates/api-header.php";

$BASE_URL = "http://" . $_SERVER['SERVER_NAME'];
$json = array();
$success = false;
$rank = "";
$cart = 0;
if (isset($_POST["appointmentId"])) {
  $Id = $_POST["appointmentId"];
  $app = appointment()->get("Id='$Id'");
  $counselor = user()->get("Id=$app->counselorId");
  $success = true;

  $booking_list = array();

  $appointment = json_decode(json_encode($app), true);
}

$json["appointmentId"] = $_POST["appointmentId"];
$json["appointment"] = $appointment;
$json["counselor"] = $counselor->firstName . " " . $counselor->lastName;
$json["success"] = $success;

echo json_encode($json);
?>
