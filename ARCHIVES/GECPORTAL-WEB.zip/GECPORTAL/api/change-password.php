<?php
include "../templates/api-header.php";

$json = array();
$success = false;
$response = "";
if (isset($_POST["username"])) {
  $username = $_POST["username"];
  $checkUserExist = user()->count("username='$username'");
  if ($checkUserExist > 0) {
    $model = user();
    $model->obj["password"] = $_POST["password"];
    $model->obj["status"] = "Active";
    $model->update("username='$username'");

    $user = user()->get("username='$username'");
    $success = true;
    $json["user"] = json_decode(json_encode($user), true);
  }
}

$json["username"] = $_POST["username"];
$json["password"] = $_POST["password"];
$json["success"] = $success;


header('Content-Type: application/json; charset=utf-8');
echo json_encode($json);
?>
