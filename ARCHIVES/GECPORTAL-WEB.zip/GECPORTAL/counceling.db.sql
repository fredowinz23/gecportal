﻿# Host: localhost  (Version 5.5.5-10.1.34-MariaDB)
# Date: 2023-05-18 13:43:48
# Generator: MySQL-Front 6.1  (Build 1.26)


#
# Structure for table "appointment"
#

DROP TABLE IF EXISTS `appointment`;
CREATE TABLE `appointment` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `createdBy` int(11) DEFAULT NULL,
  `studentId` int(11) DEFAULT NULL,
  `appointmentDate` date DEFAULT NULL,
  `status` varchar(30) DEFAULT NULL,
  `appointmentType` varchar(255) DEFAULT NULL,
  `dateAdded` date DEFAULT NULL,
  `appointmentTime` varchar(10) DEFAULT NULL,
  `purpose` text,
  `counselorId` int(11) DEFAULT NULL,
  `zoomLink` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

#
# Data for table "appointment"
#

INSERT INTO `appointment` VALUES (1,6,6,'2023-05-17','Approved','Zoom','2023-05-17','8:00AM','sdfdsfdsffds',2,'kjhkjhkjhkjhkj@dsfdsfsd.fdsfds'),(2,6,6,'2023-05-17','Pending','Chat','2023-05-17','9:00AM','jkhkjhk',2,NULL),(3,6,6,'2023-05-17','Pending','Zoom','2023-05-17','11:00AM','kjhjk',2,NULL),(4,6,6,'2023-05-17','Pending','Zoom','2023-05-17','10:00AM','dfdf',2,NULL),(5,6,6,'2023-05-18','Pending','Chat','2023-05-18','11:00AM','dsfsdfds',3,NULL);

#
# Structure for table "chat"
#

DROP TABLE IF EXISTS `chat`;
CREATE TABLE `chat` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `appointmentId` int(11) DEFAULT NULL,
  `senderId` int(11) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `time` time DEFAULT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# Data for table "chat"
#

INSERT INTO `chat` VALUES (1,1,3,'dsfdsfdsf',NULL),(2,5,6,'sample','13:33:42'),(3,5,6,'how are you today?','13:33:50'),(4,5,2,'naano ka','13:33:50'),(5,5,6,'ok lang ko','13:41:42');

#
# Structure for table "user"
#

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `Id` tinyint(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `password` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `firstName` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastName` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'Inactive',
  `role` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dateAdded` date DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isDeleted` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'false',
  PRIMARY KEY (`Id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPACT;

#
# Data for table "user"
#

INSERT INTO `user` VALUES (1,'admin','1234','Juan','De la cruz','Active','Admin',NULL,NULL,NULL,'false'),(2,'coun1','1234','aa','aa','Active','Counselor','2023-05-17',NULL,NULL,'false'),(3,'count2','808500','ben','tong','Inactive','Counselor','2023-05-17',NULL,NULL,'false'),(4,'teacher1','645929','tea','cher','Inactive','Teacher','2023-05-17',NULL,NULL,'false'),(5,'teacher2','747192','tea','cher2','Inactive','Teacher','2023-05-17',NULL,NULL,'false'),(6,'student1','1234','stu','dent','Active','Student','2023-05-17',NULL,NULL,'false'),(7,'student2','122703','stu','dent2','Inactive','Student','2023-05-17',NULL,NULL,'false');
