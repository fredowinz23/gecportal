<?php
$ROOT_DIR="../";
include $ROOT_DIR . "templates/header-blank.php";

$username = $_GET["userName"];
// $user = user()->get("");

$worker_type = work_category()->list();

?>

<style media="screen">
  .form-control{
    height: 100px;
    font-size: 25px;
  }
  .form-label{
    font-size: 30px;
  }
  .btn{
    height: 100px;
    font-size: 25px;
  }
</style>

<div class="card mt-5">
  <div class="card-body">
    <center>
    <h1>New Worker Registration Form</h1>
  </center>
<br><br><br>
  <form action="process.php?action=worker-register" enctype="multipart/form-data" method="post">

    <input type="hidden" name="username" value="<?=$username;?>">
    <b class="form-label">Worker Type</b>
    <select class="form-control" name="workCategoryId" required>
      <option value="">--Select--</option>
      <?php foreach ($worker_type as $row): ?>
          <option value="<?=$row->Id?>"><?=$row->name;?></option>
      <?php endforeach; ?>
    </select>
    <br><br>
    <b class="form-label">Why are you applying?:</b>
    <textarea name="applicationReason" class="form-control" rows="8" cols="80" required></textarea>
    <br><br>
    <b class="form-label">Describe all the skills that clients may need:</b>
    <textarea name="skillDescription" class="form-control" rows="8" cols="80" required></textarea>
    <br><br>
    <b class="form-label">Desired Rate Per Transaction</b>
    <select class="form-control" name="rate" required>
      <option value="500">P 500.00</option>
      <option value="700">P 700.00</option>
      <option value="1000">P 1,000.00</option>
      <option value="1200">P 1,200.00</option>
      <option value="1500">P 1,500.00</option>
    </select>
    <br><br>
    <b class="form-label">Upload Selfie:</b>
    <input type="file" name="selfie" class="form-control" required>
    <br><br>
    <b class="form-label">Upload Valid ID:</b>
    <input type="file" name="validId" class="form-control" required>
    <br><br>
    <b class="form-label">Upload NBI Clearance:</b>
    <input type="file" name="nbi" class="form-control" required>
    <br><br>
    <b class="form-label">Upload Police Clearance:</b>
    <input type="file" name="policeClearance" class="form-control" required>

    <button type="submit" class="btn btn-primary">Submit Application</button>


  </form>

  </div>
</div>
