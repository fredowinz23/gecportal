<?php
$ROOT_DIR="../";
include $ROOT_DIR . "templates/header-blank.php";


?>

<style media="screen">
  .form-control{
    height: 100px;
    font-size: 25px;
  }
  .form-label{
    font-size: 30px;
  }
  .btn{
    font-size: 25px;
  }
</style>

<br><br><br>
<div class="card mt-5">
  <div class="card-body">
    <center>
    <h1>We have received your registration form. We will call you after your registration is reviewed. Thank you</h1>
  </center>

<center>
  <a href="https://www.google.com" class="btn btn-primary mt-3">Close</a>


  </form>
  </div>
</div>
