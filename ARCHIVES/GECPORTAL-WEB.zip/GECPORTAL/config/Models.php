<?php
include "CRUD.php";
include "functions.php";

function user() {
	$crud = new CRUD;
	$crud->table = "user";
	return $crud;
}

function appointment() {
	$crud = new CRUD;
	$crud->table = "appointment";
	return $crud;
}

function chat() {
	$crud = new CRUD;
	$crud->table = "chat";
	return $crud;
}

?>
