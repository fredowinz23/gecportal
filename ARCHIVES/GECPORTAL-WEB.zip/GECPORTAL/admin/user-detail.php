<?php
$ROOT_DIR="../";
include $ROOT_DIR . "templates/header.php";

$Id = $_GET["Id"];

$user = user()->get("Id=$Id");
?>

<h2 class="mt-3">User Detail</h2>

<form action="process.php?action=user-add" enctype="multipart/form-data" method="post">
<div class="card">
  <div class="card-header">
    <b>Profile</b>
  </div>
  <div class="card-body">
    <div class="row">
      <div class="col-lg-4">
        <b>Username</b> <span style="color:red;"><?=$error;?></span>
        <input type="text" name="username" class="form-control" value="<?=$user->username;?>" disabled>
      </div>
      <div class="col-lg-4">
        <b>Role</b>
        <input type="text" name="role" class="form-control" value="<?=$user->role;?>" disabled>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-4">
        <b>First Name</b>
        <input type="text"class="form-control" value="<?=$user->firstName;?>" disabled>
      </div>
      <div class="col-lg-4">
        <b>Last Name</b>
        <input type="text"class="form-control" value="<?=$user->lastName;?>" disabled>
      </div>
    </div>
    <div class="row">
      <div class="col-lg-4">
        <?php if ($user->status=="Inactive"): ?>
            <b>Temporary Password</b>
            <input type="text"class="form-control" value="<?=$user->password;?>" disabled>
          <?php else: ?>
            <b>Password</b>
            <input type="text"class="form-control" value="Not Shown for Security" disabled>
            <a href="process.php?action=change-password&Id=<?=$Id;?>" class="btn btn-warning btn-sm mt-3">Create New Temporary Password</a>
        <?php endif; ?>
      </div>

        <div class="col-lg-4">
            <b>Status</b>
            <input type="text"class="form-control" value="<?=$user->status;?>" disabled>
            <?php if ($user->status=="Pending"): ?>
              <a href="process.php?action=change-user-status&Id=<?=$Id;?>&status=Active" class="btn btn-warning btn-sm mt-3">Activate</a>
            <?php endif; ?>
        </div>
    </div>

    </div>

</div>

</form>

<?php include $ROOT_DIR . "templates/footer.php"; ?>
