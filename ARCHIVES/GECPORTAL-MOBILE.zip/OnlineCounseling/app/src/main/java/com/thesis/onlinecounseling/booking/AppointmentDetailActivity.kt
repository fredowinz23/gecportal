package com.thesis.onlinecounseling.booking

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.recyclerview.widget.LinearLayoutManager
import com.thesis.onlinecounseling.api.ApiInterface
import com.thesis.onlinecounseling.api.RetrofitClient
import com.thesis.onlinecounseling.api.UserSession
import com.thesis.onlinecounseling.auth.ChangePasswordActivity
import com.thesis.onlinecounseling.chats.ChatActivity
import com.thesis.onlinecounseling.databinding.ActivityAppointmentDetailBinding
import retrofit2.Call
import retrofit2.Response
import java.util.*

class AppointmentDetailActivity : AppCompatActivity() {

    lateinit var binding: ActivityAppointmentDetailBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityAppointmentDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

        binding.ivBack.setOnClickListener {
            finish()
        }
        val appointmentId = intent.extras?.getInt("appointmentId", 0)
        getAppointmentDetail(appointmentId)
    }

    private fun getAppointmentDetail(appointmentId: Int?) {
        val retrofit = RetrofitClient.getInstance(this)
        val retrofitAPI = retrofit.create(ApiInterface::class.java)

        val apiRequest = AppointmentDetailRequest(appointmentId!!)
        val call = retrofitAPI.getAppointmentById(apiRequest)

        call.enqueue(object : retrofit2.Callback<AppointmentDetailRequest?> {
            override fun onResponse(call: Call<AppointmentDetailRequest?>, response: Response<AppointmentDetailRequest?>) {

                binding.progressBar.visibility = View.GONE

                val response: AppointmentDetailRequest? = response.body()

                binding.tvCounselor.text = response!!.counselor
                binding.tvAppointmentDate.text = response.appointment!!.appointmentDate
                binding.tvAppointmentTime.text = response.appointment!!.appointmentTime
                binding.tvAppointmentType.text = response.appointment!!.appointmentType
                binding.tvPurpose.text = response.appointment!!.purpose

                binding.btnChat.visibility = View.GONE
                binding.btnZoomLink.visibility = View.GONE
                if (response.appointment!!.appointmentType=="Zoom"){
                    binding.btnZoomLink.visibility = View.VISIBLE
                    binding.btnZoomLink.text = "Link: " + response.appointment!!.zoomLink
                }
                if (response.appointment!!.appointmentType=="Chat"){
                    binding.btnChat.visibility = View.VISIBLE
                }

                binding.btnClose.setOnClickListener {
                    finish()
                }

                binding.btnChat.setOnClickListener {
                    val intent = Intent(this@AppointmentDetailActivity, ChatActivity::class.java)
                    intent.putExtra("appointmentId", appointmentId)
                    startActivity(intent)
                }
            }

            override fun onFailure(call: Call<AppointmentDetailRequest?>, t: Throwable) {

                binding.progressBar.visibility = View.GONE

                Log.e("Login Error", t.message.toString())

                Toast.makeText(
                    this@AppointmentDetailActivity,
                    "Internet Connection Error",
                    Toast.LENGTH_LONG
                ).show()
            }

        })
    }

}