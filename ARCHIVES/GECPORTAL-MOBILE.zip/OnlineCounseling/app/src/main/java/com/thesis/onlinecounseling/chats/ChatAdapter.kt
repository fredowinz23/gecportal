package com.thesis.onlinecounseling.chats

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.RecyclerView
import com.thesis.onlinecounseling.R
import com.thesis.onlinecounseling.api.UserSession
import com.thesis.onlinecounseling.models.Chat
import com.thesis.onlinecounseling.models.User

class ChatAdapter(private var context: Context?, private val mList: List<Chat>) : RecyclerView.Adapter<ChatAdapter.ViewHolder>() {

    // create new views
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        // inflates the card_view_design view
        // that is used to hold list item
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_chat_me, parent, false)

        return ViewHolder(view)
    }

    // binds the list items to a view
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {


        val userSession = UserSession(context)

        val item = mList[position]

        if (userSession.userId==item.senderId){
            holder.clChatOther.visibility = View.GONE
            holder.clChatMe.visibility = View.VISIBLE
        }
        else{
            holder.clChatOther.visibility = View.VISIBLE
            holder.clChatMe.visibility = View.GONE
        }

        holder.messageMe.text = item.message
        holder.dateMe.text = item.time

        holder.messageOther.text = item.message
        holder.dateOther.text = item.time
    }

    // return the number of the items in the list
    override fun getItemCount(): Int {
        return mList.size
    }

    // Holds the views for adding it to image and text
    class ViewHolder(ItemView: View) : RecyclerView.ViewHolder(ItemView) {
        val messageMe: TextView = itemView.findViewById(R.id.tvMessageMe)
        val messageOther: TextView = itemView.findViewById(R.id.tvMessageOther)
        val dateMe: TextView = itemView.findViewById(R.id.tvDateMe)
        val dateOther: TextView = itemView.findViewById(R.id.tvDateOther)
        val clChatMe: ConstraintLayout = itemView.findViewById(R.id.clChatMe)
        val clChatOther: ConstraintLayout = itemView.findViewById(R.id.clChatOther)
    }
}
