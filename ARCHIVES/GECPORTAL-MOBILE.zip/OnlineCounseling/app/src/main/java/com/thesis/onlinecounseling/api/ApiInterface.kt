package com.thesis.onlinecounseling.api

import com.thesis.onlinecounseling.auth.LoginRequest
import com.thesis.onlinecounseling.booking.*
import com.thesis.onlinecounseling.chats.ChatRequest
import com.thesis.onlinecounseling.chats.SendChatRequest
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Headers


interface ApiInterface {
    @Headers("Content-Type: application/json")
    @POST("api/login.php")
    fun loginUser(@Body loginRequest: LoginRequest): Call<LoginRequest>

    @Headers("Content-Type: application/json")
    @POST("api/post-chat.php")
    fun postChat(@Body sendChatRequest: SendChatRequest): Call<SendChatRequest>

    @Headers("Content-Type: application/json")
    @POST("api/change-password.php")
    fun changePassword(@Body loginRequest: LoginRequest): Call<LoginRequest>

    @Headers("Content-Type: application/json")
    @POST("api/submit-booking-request.php")
    fun submitBookingRequest(@Body newBookingRequest: NewBookingRequest): Call<NewBookingRequest>

    @Headers("Content-Type: application/json")
    @POST("api/my-booking-list.php")
    fun getMyBookingList(@Body bookingListRequest: BookingListRequest): Call<BookingListRequest>

    @Headers("Content-Type: application/json")
    @POST("api/todays-appointment-list.php")
    fun getTodaysAppointment(@Body todaysAppointmentRequest: TodaysAppointmentRequest): Call<TodaysAppointmentRequest>

    @Headers("Content-Type: application/json")
    @POST("api/chat-list.php")
    fun getChatList(@Body chatRequest: ChatRequest): Call<ChatRequest>

    @Headers("Content-Type: application/json")
    @POST("api/appointment-by-id.php")
    fun getAppointmentById(@Body appointmentDetailRequest: AppointmentDetailRequest): Call<AppointmentDetailRequest>

    @Headers("Content-Type: application/json")
    @POST("api/counselor-list.php")
    fun getCounselorList(@Body counselorListRequest: CounselorListRequest): Call<CounselorListRequest>

    @Headers("Content-Type: application/json")
    @POST("api/counselor-available-time.php")
    fun getAvailableTime(@Body availableTimeRequest: AvailableTimeRequest): Call<AvailableTimeRequest>

//    @Headers("Content-Type: application/json")
//    @POST("api/profile.php")
//    fun getProfile(@Body profileInfo: ProfileInfo): Call<ProfileInfo>
//
//    @Headers("Content-Type: application/json")
//    @POST("api/schedule-by-date.php")
//    fun getScheduleInfo(@Body scheduleInfo: ScheduleInfo): Call<ScheduleInfo>
//
//    @Headers("Content-Type: application/json")
//    @POST("api/nurse-schedule-list.php")
//    fun getMyScheduleListInfo(@Body myScheduleListInfo: MyScheduleListInfo): Call<MyScheduleListInfo>
//
//    @Headers("Content-Type: application/json")
//    @POST("api/my-leave-request.php")
//    fun getMyLeaveRequest(@Body leaveInfo: LeaveInfo): Call<LeaveInfo>
//
//    @Headers("Content-Type: application/json")
//    @POST("api/leave-type-list.php")
//    fun getLeaveTypeList(@Body leaveTypeInfo: LeaveTypeInfo): Call<LeaveTypeInfo>
//
//    @Headers("Content-Type: application/json")
//    @POST("api/submit-leave-request.php")
//    fun submitLeaveRequest(@Body leaveRequest: LeaveRequest): Call<LeaveRequest>


}