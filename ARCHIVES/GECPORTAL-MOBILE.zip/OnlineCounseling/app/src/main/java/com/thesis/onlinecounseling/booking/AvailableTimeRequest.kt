package com.thesis.onlinecounseling.booking

import com.google.gson.annotations.SerializedName
import com.thesis.onlinecounseling.models.Availability
import com.thesis.onlinecounseling.models.User

data class AvailableTimeRequest(
    @SerializedName("username")
    var username: String,

    @SerializedName("counselorId")
    var counselorId: Int,

    @SerializedName("appointmentDate")
    var appointmentDate: String,

    @SerializedName("success")
    var success: String = "",

    @SerializedName("availability")
    var availability: Availability? = null
)