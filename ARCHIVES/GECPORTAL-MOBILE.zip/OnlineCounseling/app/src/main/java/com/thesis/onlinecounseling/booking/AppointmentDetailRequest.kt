package com.thesis.onlinecounseling.booking

import com.google.gson.annotations.SerializedName
import com.thesis.onlinecounseling.models.Appointment
import com.thesis.onlinecounseling.models.Availability
import com.thesis.onlinecounseling.models.User

data class AppointmentDetailRequest(
    @SerializedName("appointmentId")
    var appointmentId: Int,

    @SerializedName("appointment")
    var appointment: Appointment? = null,

    @SerializedName("success")
    var success: String = "",

    @SerializedName("counselor")
    var counselor: String? = ""
)