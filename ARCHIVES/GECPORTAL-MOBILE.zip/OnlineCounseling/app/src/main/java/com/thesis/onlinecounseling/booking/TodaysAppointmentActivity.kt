package com.thesis.onlinecounseling.booking

import android.app.DatePickerDialog
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.thesis.onlinecounseling.R
import com.thesis.onlinecounseling.api.ApiInterface
import com.thesis.onlinecounseling.api.RetrofitClient
import com.thesis.onlinecounseling.api.UserSession
import com.thesis.onlinecounseling.databinding.ActivityBookingFormBinding
import com.thesis.onlinecounseling.databinding.ActivityTodaysAppointmentBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.*

class TodaysAppointmentActivity : AppCompatActivity() {

    lateinit var binding: ActivityTodaysAppointmentBinding
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityTodaysAppointmentBinding.inflate(layoutInflater)
        setContentView(binding.root)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

        binding.ivBack.setOnClickListener {
            finish()
        }


        getBookingList()

    }

    private fun getBookingList() {
        val retrofit = RetrofitClient.getInstance(this)
        val retrofitAPI = retrofit.create(ApiInterface::class.java)

        val userSession = UserSession(this)
        val apiRequest = TodaysAppointmentRequest(userSession.username!!)
        val call = retrofitAPI.getTodaysAppointment(apiRequest)

        call.enqueue(object : retrofit2.Callback<TodaysAppointmentRequest?> {
            override fun onResponse(call: Call<TodaysAppointmentRequest?>, response: Response<TodaysAppointmentRequest?>) {

                binding.progressBar.visibility = View.GONE

                val responseFromAPI: TodaysAppointmentRequest? = response.body()

                val groupLinear = LinearLayoutManager(this@TodaysAppointmentActivity)
                binding.rvStoreList.layoutManager = groupLinear
                val data = responseFromAPI?.booking_list!!

                if (data.isNotEmpty()){
                    binding.tvNoAppointment.visibility = View.GONE
                }
                else{
                    binding.tvNoAppointment.visibility = View.VISIBLE
                }

                val adapter = BookingListAdapter(this@TodaysAppointmentActivity, data)
                binding.rvStoreList.adapter = adapter
            }

            override fun onFailure(call: Call<TodaysAppointmentRequest?>, t: Throwable) {

                binding.progressBar.visibility = View.GONE

                Log.e("Login Error", t.message.toString())

                Toast.makeText(
                    this@TodaysAppointmentActivity,
                    "Internet Connection Error",
                    Toast.LENGTH_LONG
                ).show()
            }

        })
    }
}