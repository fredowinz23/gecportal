package com.thesis.onlinecounseling.models

import com.google.gson.annotations.SerializedName

data class User(
    @SerializedName("Id")
    var id: Int = 0,

    @SerializedName("username")
    var username: String = "",

    @SerializedName("firstName")
    var firstName: String = "",

    @SerializedName("lastName")
    var lastName: String = "",

    @SerializedName("phone")
    var phone: String = "",

    @SerializedName("email")
    var email: String = "",

    @SerializedName("status")
    var status: String = "",

    @SerializedName("department")
    var department: String = "",

)