package com.thesis.onlinecounseling.chats

import com.google.gson.annotations.SerializedName
import com.thesis.onlinecounseling.models.Appointment

data class SendChatRequest(
    @SerializedName("appointmentId")
    var appointmentId: Int,

    @SerializedName("username")
    var username: String,

    @SerializedName("message")
    var message: String,

    @SerializedName("success")
    var success: String = "",

)