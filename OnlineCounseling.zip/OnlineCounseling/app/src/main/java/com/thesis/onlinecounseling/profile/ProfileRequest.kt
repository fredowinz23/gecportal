package com.thesis.onlinecounseling.profile

import com.google.gson.annotations.SerializedName
import com.thesis.onlinecounseling.models.User

data class ProfileRequest(
    @SerializedName("username")
    var username: String,

    @SerializedName("success")
    var success: Boolean = false,

    @SerializedName("user")
    var user: User? = null
)