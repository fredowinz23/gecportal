package com.thesis.onlinecounseling

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.recyclerview.widget.LinearLayoutManager
import com.thesis.onlinecounseling.api.ApiInterface
import com.thesis.onlinecounseling.api.RetrofitClient
import com.thesis.onlinecounseling.api.UserSession
import com.thesis.onlinecounseling.booking.CounselorListAdapter
import com.thesis.onlinecounseling.booking.CounselorListRequest
import com.thesis.onlinecounseling.databinding.ActivityListOfCounselorBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ListOfCounselorActivity : AppCompatActivity() {

    private lateinit var binding: ActivityListOfCounselorBinding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityListOfCounselorBinding.inflate(layoutInflater)
        setContentView(binding.root)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

        binding.ivBack.setOnClickListener {
            finish()
        }

        getListOfCounselors()
    }

    private fun getListOfCounselors() {
        val retrofit = RetrofitClient.getInstance(this)
        val retrofitAPI = retrofit.create(ApiInterface::class.java)

        val userSession = UserSession(this)
        val cardioList = CounselorListRequest(userSession.username!!)
        val call = retrofitAPI.getCounselorList(cardioList)

        call.enqueue(object : Callback<CounselorListRequest?> {
            override fun onResponse(call: Call<CounselorListRequest?>, response: Response<CounselorListRequest?>) {

                val responseFromAPI: CounselorListRequest? = response.body()

                val groupLinear = LinearLayoutManager(this@ListOfCounselorActivity)
                binding.rvCounselorList.layoutManager = groupLinear
                val data = responseFromAPI?.counselor_list!!

                val adapter = CounselorListAdapter(this@ListOfCounselorActivity, data)
                adapter.behaviour = "BookByCounselor"
                binding.rvCounselorList.adapter = adapter
            }

            override fun onFailure(call: Call<CounselorListRequest?>, t: Throwable) {

                Log.e("Login Error", t.message.toString())

                Toast.makeText(
                    this@ListOfCounselorActivity,
                    "Internet Connection Error",
                    Toast.LENGTH_LONG
                ).show()
            }
        })
    }
}