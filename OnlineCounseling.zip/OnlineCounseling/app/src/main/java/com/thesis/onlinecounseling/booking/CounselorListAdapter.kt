package com.thesis.onlinecounseling.booking

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat.startActivity
import androidx.recyclerview.widget.RecyclerView
import com.thesis.onlinecounseling.ListOfCounselorActivity
import com.thesis.onlinecounseling.MainActivity
import com.thesis.onlinecounseling.R
import com.thesis.onlinecounseling.api.UserSession
import com.thesis.onlinecounseling.models.User

class CounselorListAdapter(private var context: Context?, private val mList: List<User>) : RecyclerView.Adapter<CounselorListAdapter.ViewHolder>() {

    var behaviour: String = ""

    // create new views
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        // inflates the card_view_design view
        // that is used to hold list item
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.adapter_counselor, parent, false)
        return ViewHolder(view)
    }

    // binds the list items to a view
    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        val item = mList[position]
        holder.name.text = item.firstName +" "+ item.lastName

        if (behaviour=="Selectable"){
            holder.item.setOnClickListener {
                val bookingForm = context as BookingFormActivity
                bookingForm.counselorId = item.id
                bookingForm.binding.tvCounselor.text = item.firstName +" "+item.lastName
                bookingForm.bottomSheetDialog.hide()
            }
        }

        if (behaviour=="BookByCounselor"){
            holder.item.setOnClickListener {
                val intent = Intent(context, BookingFormActivity::class.java)
                intent.putExtra("studentId", UserSession(context).userId)
                intent.putExtra("studentName", UserSession(context).fullName)
                intent.putExtra("counselorId", item.id)
                intent.putExtra("counselorName", "${item.firstName} ${item.lastName}")
                (context as ListOfCounselorActivity).startActivity(intent)
            }
        }
    }

    // return the number of the items in the list
    override fun getItemCount(): Int {
        return mList.size
    }

    // Holds the views for adding it to image and text
    class ViewHolder(ItemView: View) : RecyclerView.ViewHolder(ItemView) {
        val name: TextView = itemView.findViewById(R.id.tvName)
        val item: LinearLayout = itemView.findViewById(R.id.llItem)
    }
}
