package com.thesis.onlinecounseling.booking

import com.google.gson.annotations.SerializedName
import com.thesis.onlinecounseling.models.User

data class CounselorListRequest(
    @SerializedName("username")
    var username: String,

    @SerializedName("success")
    var success: String = "",

    @SerializedName("counselor_list")
    var counselor_list: List<User>? = null
)