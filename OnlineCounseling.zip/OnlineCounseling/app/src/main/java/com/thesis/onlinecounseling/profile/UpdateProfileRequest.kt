package com.thesis.onlinecounseling.profile

import com.google.gson.annotations.SerializedName
import com.thesis.onlinecounseling.models.User

data class UpdateProfileRequest(
    @SerializedName("username")
    var username: String,

    @SerializedName("address")
    var address: String,

    @SerializedName("course")
    var course: String,

    @SerializedName("department")
    var department: String,

    @SerializedName("idNumber")
    var idNumber: String,

    @SerializedName("phone")
    var phone: String,

    @SerializedName("email")
    var email: String,


    @SerializedName("success")
    var success: Boolean = false
)