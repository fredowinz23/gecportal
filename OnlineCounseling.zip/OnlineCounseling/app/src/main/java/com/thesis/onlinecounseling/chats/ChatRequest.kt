package com.thesis.onlinecounseling.chats

import com.google.gson.annotations.SerializedName
import com.thesis.onlinecounseling.models.Appointment
import com.thesis.onlinecounseling.models.Chat

data class ChatRequest(
    @SerializedName("appointmentId")
    var appointmentId: Int,

    @SerializedName("success")
    var success: String = "",

    @SerializedName("chat_list")
    var chat_list: List<Chat>? = null
)