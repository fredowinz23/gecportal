package com.thesis.onlinecounseling.models

import com.google.gson.annotations.SerializedName

data class Chat(
    @SerializedName("Id")
    var id: Int = 0,

    @SerializedName("appointmentId")
    var appointmentId: Int = 0,

    @SerializedName("senderId")
    var senderId: Int = 0,

    @SerializedName("message")
    var message: String = "",

    @SerializedName("time")
    var time: String = "",
)