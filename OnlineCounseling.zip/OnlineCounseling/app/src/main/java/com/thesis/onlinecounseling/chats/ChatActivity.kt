package com.thesis.onlinecounseling.chats

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.recyclerview.widget.LinearLayoutManager
import com.thesis.onlinecounseling.MainActivity
import com.thesis.onlinecounseling.api.ApiInterface
import com.thesis.onlinecounseling.api.RetrofitClient
import com.thesis.onlinecounseling.api.UserSession
import com.thesis.onlinecounseling.auth.ChangePasswordActivity
import com.thesis.onlinecounseling.auth.LoginActivity
import com.thesis.onlinecounseling.auth.LoginRequest
import com.thesis.onlinecounseling.booking.BookingListAdapter
import com.thesis.onlinecounseling.databinding.ActivityChatBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ChatActivity : AppCompatActivity() {

    lateinit var binding: ActivityChatBinding
    var status = ""
    var fullName = ""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityChatBinding.inflate(layoutInflater)
        setContentView(binding.root)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

        val appointmentId = intent.extras?.getInt("appointmentId", 0)
        status = intent.extras?.getString("status", "")!!
        fullName = intent.extras?.getString("fullName", "")!!
        getChatActivity(appointmentId)

        binding.btnSend.setOnClickListener {
            postChat(appointmentId!!, binding.etChatMessage.text.toString())
            binding.etChatMessage.setText("")
        }
        if (status=="Done"){
            binding.layoutGchatChatbox.visibility = View.GONE
        }
    }

    private fun postChat(appointmentId: Int, message: String) {
        val retrofit = RetrofitClient.getInstance(this)
        val retrofitAPI = retrofit.create(ApiInterface::class.java)

        val userSession = UserSession(this)
        val loginModal = SendChatRequest(appointmentId, userSession.username!!, message)
        val call = retrofitAPI.postChat(loginModal)

        call.enqueue(object : Callback<SendChatRequest?> {
            override fun onResponse(call: Call<SendChatRequest?>, response: Response<SendChatRequest?>) {

                // we are getting response from our body
                // and passing it to our modal class.
                val responseFromAPI: SendChatRequest? = response.body()

                if (status!="Done"){
                    getChatActivity(appointmentId)
                }

            }

            override fun onFailure(call: Call<SendChatRequest?>, t: Throwable) {
                // setting text to our text view when
                // we get error response from API.

                Log.e("Login Error", t.message.toString())
            }

        })
    }

    private fun getChatActivity(appointmentId: Int?) {
        val retrofit = RetrofitClient.getInstance(this)
        val retrofitAPI = retrofit.create(ApiInterface::class.java)

        val apiRequest = ChatRequest(appointmentId!!)
        val call = retrofitAPI.getChatList(apiRequest)

        call.enqueue(object : Callback<ChatRequest?> {
            override fun onResponse(call: Call<ChatRequest?>, response: Response<ChatRequest?>) {

                val responseFromAPI: ChatRequest? = response.body()

                val groupLinear = LinearLayoutManager(this@ChatActivity)
                groupLinear.stackFromEnd = true
                binding.rvChatList.layoutManager = groupLinear
                val data = responseFromAPI?.chat_list!!

                val adapter = ChatAdapter(this@ChatActivity, data)
                adapter.fullName = fullName
                binding.rvChatList.adapter = adapter

                Handler(Looper.getMainLooper()).postDelayed({
                    getChatActivity(appointmentId)
                }, 2000)
            }

            override fun onFailure(call: Call<ChatRequest?>, t: Throwable) {

                Log.e("Login Error", t.message.toString())

                Toast.makeText(
                    this@ChatActivity,
                    "Internet Connection Error",
                    Toast.LENGTH_LONG
                ).show()
            }

        })
    }
}