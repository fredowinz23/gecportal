package com.thesis.onlinecounseling.api

import com.thesis.onlinecounseling.auth.LoginRequest
import com.thesis.onlinecounseling.booking.*
import com.thesis.onlinecounseling.chats.ChatRequest
import com.thesis.onlinecounseling.chats.SendChatRequest
import com.thesis.onlinecounseling.profile.ProfileRequest
import com.thesis.onlinecounseling.profile.UpdateProfileRequest
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Headers


interface ApiInterface {
    @Headers("Content-Type: application/json")
    @POST("api/login.php")
    fun loginUser(@Body loginRequest: LoginRequest): Call<LoginRequest>

    @Headers("Content-Type: application/json")
    @POST("api/post-chat.php")
    fun postChat(@Body sendChatRequest: SendChatRequest): Call<SendChatRequest>

    @Headers("Content-Type: application/json")
    @POST("api/change-password.php")
    fun changePassword(@Body loginRequest: LoginRequest): Call<LoginRequest>

    @Headers("Content-Type: application/json")
    @POST("api/submit-booking-request.php")
    fun submitBookingRequest(@Body newBookingRequest: NewBookingRequest): Call<NewBookingRequest>

    @Headers("Content-Type: application/json")
    @POST("api/submit-report-request.php")
    fun submitReportRequest(@Body appointmentReportRequest: AppointmentReportRequest): Call<AppointmentReportRequest>

    @Headers("Content-Type: application/json")
    @POST("api/my-booking-list.php")
    fun getMyBookingList(@Body bookingListRequest: BookingListRequest): Call<BookingListRequest>

    @Headers("Content-Type: application/json")
    @POST("api/todays-appointment-list.php")
    fun getTodaysAppointment(@Body todaysAppointmentRequest: TodaysAppointmentRequest): Call<TodaysAppointmentRequest>

    @Headers("Content-Type: application/json")
    @POST("api/chat-list.php")
    fun getChatList(@Body chatRequest: ChatRequest): Call<ChatRequest>

    @Headers("Content-Type: application/json")
    @POST("api/appointment-by-id.php")
    fun getAppointmentById(@Body appointmentDetailRequest: AppointmentDetailRequest): Call<AppointmentDetailRequest>

    @Headers("Content-Type: application/json")
    @POST("api/counselor-list.php")
    fun getCounselorList(@Body counselorListRequest: CounselorListRequest): Call<CounselorListRequest>

    @Headers("Content-Type: application/json")
    @POST("api/counselor-available-time.php")
    fun getAvailableTime(@Body availableTimeRequest: AvailableTimeRequest): Call<AvailableTimeRequest>

    @Headers("Content-Type: application/json")
    @POST("api/get-student-by-id-number.php")
    fun getStudentByIdNumber(@Body studentRequest: StudentRequest): Call<StudentRequest>

    @Headers("Content-Type: application/json")
    @POST("api/get-student-by-username.php")
    fun getStudentByUsername(@Body profileRequest: ProfileRequest): Call<ProfileRequest>

    @Headers("Content-Type: application/json")
    @POST("api/update-profile.php")
    fun updateProfile(@Body updateProfileRequest: UpdateProfileRequest): Call<UpdateProfileRequest>

}