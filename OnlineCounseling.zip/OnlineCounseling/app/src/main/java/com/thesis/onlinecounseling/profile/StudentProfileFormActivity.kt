package com.thesis.onlinecounseling.profile

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import com.thesis.onlinecounseling.api.ApiInterface
import com.thesis.onlinecounseling.api.RetrofitClient
import com.thesis.onlinecounseling.api.UserSession
import com.thesis.onlinecounseling.databinding.ActivityStudentProfileFormBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class StudentProfileFormActivity : AppCompatActivity() {

    lateinit var binding: ActivityStudentProfileFormBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityStudentProfileFormBinding.inflate(layoutInflater)
        setContentView(binding.root)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

        binding.ivBack.setOnClickListener {
            updateProfileInfo()
            finish()
        }

        getStudentRecord()

    }

    private fun updateProfileInfo() {
        val retrofit = RetrofitClient.getInstance(this)
        val retrofitAPI = retrofit.create(ApiInterface::class.java)

        val request = UpdateProfileRequest(UserSession(this).username!!,
            binding.etAddress.text.toString(),
            binding.etCourse.text.toString(),
            binding.etDepartment.text.toString(),
            binding.etIdNumber.text.toString(),
            binding.etPhone.text.toString(),
            binding.etEmail.text.toString())
        val call = retrofitAPI.updateProfile(request)

        call.enqueue(object : Callback<UpdateProfileRequest?> {
            override fun onResponse(call: Call<UpdateProfileRequest?>, response: Response<UpdateProfileRequest?>) {

                // we are getting response from our body
                // and passing it to our modal class.
                val profile: UpdateProfileRequest? = response.body()
                finish()
            }

            override fun onFailure(call: Call<UpdateProfileRequest?>, t: Throwable) {
                // setting text to our text view when
                // we get error response from API.

                Toast.makeText(
                    this@StudentProfileFormActivity,
                    t.message.toString(),
                    Toast.LENGTH_LONG
                ).show()

                Log.e("Login Error", t.message.toString())
                finish()
            }

        })
    }

    private fun getStudentRecord() {
        val retrofit = RetrofitClient.getInstance(this)
        val retrofitAPI = retrofit.create(ApiInterface::class.java)

        val request = ProfileRequest(UserSession(this).username!!)
        val call = retrofitAPI.getStudentByUsername(request)

        call.enqueue(object : Callback<ProfileRequest?> {
            override fun onResponse(call: Call<ProfileRequest?>, response: Response<ProfileRequest?>) {

                // we are getting response from our body
                // and passing it to our modal class.
                val profile: ProfileRequest? = response.body()

                if (profile?.success!!){
                    binding.tvUsername.text = profile.user?.username
                    binding.tvFirstName.text = profile.user?.firstName
                    binding.tvLastName.text = profile.user?.lastName
                    binding.etAddress.setText(profile.user?.address)
                    binding.etCourse.setText(profile.user?.course)
                    binding.etDepartment.setText(profile.user?.department)
                    binding.etIdNumber.setText(profile.user?.idNumber)
                    binding.etPhone.setText(profile.user?.phone)
                    binding.etEmail.setText(profile.user?.email)
                }
                else{
                    Toast.makeText(
                        this@StudentProfileFormActivity,
                        "Internet Error",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }

            override fun onFailure(call: Call<ProfileRequest?>, t: Throwable) {
                // setting text to our text view when
                // we get error response from API.

                Toast.makeText(
                    this@StudentProfileFormActivity,
                    t.message.toString(),
                    Toast.LENGTH_LONG
                ).show()

                Log.e("Login Error", t.message.toString())
            }

        })
    }
}