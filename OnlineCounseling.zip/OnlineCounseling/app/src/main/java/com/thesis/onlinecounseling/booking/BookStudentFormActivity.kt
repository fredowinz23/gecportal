package com.thesis.onlinecounseling.booking

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatDelegate
import com.thesis.onlinecounseling.api.ApiInterface
import com.thesis.onlinecounseling.api.RetrofitClient
import com.thesis.onlinecounseling.databinding.ActivityBookStudentFormBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class BookStudentFormActivity : AppCompatActivity() {

    private lateinit var binding: ActivityBookStudentFormBinding
    var userId = 0
    var fullName = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityBookStudentFormBinding.inflate(layoutInflater)
        setContentView(binding.root)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

        userId = intent.extras?.getInt("userId", 0)!!
        fullName = intent.extras?.getString("fullName", "")!!

        binding.btnSubmit.setOnClickListener {
            if (binding.etIdNumber.text.isEmpty()){
                Toast.makeText(
                    this,
                    "Please Enter ID Number",
                    Toast.LENGTH_LONG
                ).show()
            }
            else{
                postLoginData(binding.etIdNumber.text.toString())
            }
        }
    }

    private fun postLoginData(idNumber: String) {
        val retrofit = RetrofitClient.getInstance(this)
        val retrofitAPI = retrofit.create(ApiInterface::class.java)

        binding.btnSubmit.visibility = View.GONE
        binding.progressBar.visibility = View.VISIBLE

        val request = StudentRequest(idNumber)
        val call = retrofitAPI.getStudentByIdNumber(request)

        call.enqueue(object : Callback<StudentRequest?> {
            override fun onResponse(call: Call<StudentRequest?>, response: Response<StudentRequest?>) {

                // we are getting response from our body
                // and passing it to our modal class.
                val responseFromAPI: StudentRequest? = response.body()

                if (responseFromAPI?.success!!){
                    val intent = Intent(this@BookStudentFormActivity, BookingFormActivity::class.java)
                    intent.putExtra("studentId", responseFromAPI.student?.id)
                    intent.putExtra("studentName", "${responseFromAPI.student?.firstName} ${responseFromAPI.student?.lastName}")
                    intent.putExtra("counselorId", userId)
                    intent.putExtra("counselorName", fullName)
                    startActivity(intent)
                    finish()
                }
                else{
                    binding.progressBar.visibility = View.GONE
                    binding.btnSubmit.visibility = View.VISIBLE
                    Toast.makeText(
                        this@BookStudentFormActivity,
                        "ID number does not exist",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }

            override fun onFailure(call: Call<StudentRequest?>, t: Throwable) {
                // setting text to our text view when
                // we get error response from API.

                Toast.makeText(
                    this@BookStudentFormActivity,
                    t.message.toString(),
                    Toast.LENGTH_LONG
                ).show()

                binding.progressBar.visibility = View.GONE
                binding.btnSubmit.visibility = View.VISIBLE
                Log.e("Login Error", t.message.toString())
            }

        })
    }
}