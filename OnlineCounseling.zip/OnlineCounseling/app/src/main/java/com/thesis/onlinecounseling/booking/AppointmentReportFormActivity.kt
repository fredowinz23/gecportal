package com.thesis.onlinecounseling.booking

import android.app.DatePickerDialog
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.thesis.onlinecounseling.R
import com.thesis.onlinecounseling.api.ApiInterface
import com.thesis.onlinecounseling.api.RetrofitClient
import com.thesis.onlinecounseling.api.UserSession
import com.thesis.onlinecounseling.databinding.ActivityAppointmentReportFormBinding
import com.thesis.onlinecounseling.databinding.ActivityBookingFormBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.*

class AppointmentReportFormActivity : AppCompatActivity() {

    lateinit var binding: ActivityAppointmentReportFormBinding
    var appointmentId = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityAppointmentReportFormBinding.inflate(layoutInflater)
        setContentView(binding.root)
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

        appointmentId = intent.extras?.getInt("appointmentId", 0)!!


        binding.ivBack.setOnClickListener {
            finish()
        }


        binding.btnSave.setOnClickListener {
            if (binding.etReport.text.isEmpty()){
                Toast.makeText(
                    this@AppointmentReportFormActivity,
                    "Fields Must not be empty.",
                    Toast.LENGTH_LONG
                ).show()
            }
            else{
                submitRequest(binding.etReport.text.toString())
            }
        }
    }


    private fun submitRequest(report: String) {
        val retrofit = RetrofitClient.getInstance(this)
        val retrofitAPI = retrofit.create(ApiInterface::class.java)

        binding.btnSave.visibility = View.GONE
        binding.progressBar.visibility = View.VISIBLE

        val apiRequest = AppointmentReportRequest(appointmentId, report)
        val call = retrofitAPI.submitReportRequest(apiRequest)

        call.enqueue(object : Callback<AppointmentReportRequest?> {
            override fun onResponse(call: Call<AppointmentReportRequest?>, response: Response<AppointmentReportRequest?>) {
                val responseFromAPI: AppointmentReportRequest? = response.body()
                finish()
            }

            override fun onFailure(call: Call<AppointmentReportRequest?>, t: Throwable) {
                Toast.makeText(
                    this@AppointmentReportFormActivity,
                    "Internet Connection Error",
                    Toast.LENGTH_LONG
                ).show()

                binding.progressBar.visibility = View.GONE
                binding.btnSave.visibility = View.VISIBLE
                Log.e("Login Error", t.message.toString())
            }
        })
    }
}